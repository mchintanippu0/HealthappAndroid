package com.example.healthapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;

import java.util.ArrayList;

public class MyHealthActivity extends AppCompatActivity {

    ListView lvCode;
    ListView lvDate;
    ListView lvResult;
    LinearLayout linearLayout;
   // ArrayList<String> listItems=new ArrayList<String>();
    //ArrayAdapter<String> adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_health);
        findViews();
        fillData();
    }

    private void fillData() {

        String [] arrCode = {"Blood","Cereb", "Syno"};
        lvCode.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,arrCode));

        String [] arrDate = {"2016-07-25","2016-06-10", "2016-04-30"};
        lvDate.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,arrDate));

        String [] arrResult = {"Normal","Bad", "Normal"};
        lvResult.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,arrResult));

       DisplayMetrics displayMetrics = getBaseContext().getResources().getDisplayMetrics();
        float dpHeight = displayMetrics.heightPixels / displayMetrics.density;
        float dpWidth = displayMetrics.widthPixels / displayMetrics.density;
/* */
        //int w = linearLayout.getLayoutParams().width/3;
        int w = (int)dpWidth;
        ViewGroup.LayoutParams lp1 = lvCode.getLayoutParams();
        lp1.width = w;
        lvCode.setLayoutParams(lp1);


        ViewGroup.LayoutParams lp2 = lvDate.getLayoutParams();
        lp2.width = w;
        lvDate.setLayoutParams(lp2);


        ViewGroup.LayoutParams lp3 = lvResult.getLayoutParams();
        lp3.width = w;
        lvResult.setLayoutParams(lp3);
       // listView.setAdapter(new CustomListAdapetr(this, titles));
    }

    private void findViews() {
        lvCode = (ListView) findViewById(R.id.lvCode);
        lvDate = (ListView) findViewById(R.id.lvDate);
        lvResult = (ListView) findViewById(R.id.lvResult);
        linearLayout = (LinearLayout)findViewById(R.id.linearLayout);
    }
    public void openHome(View view) {
        startActivity(new Intent(this, OptionsActivity.class));
    }
}
