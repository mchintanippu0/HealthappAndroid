package com.example.healthapplication;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class FindUsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_find_us);
    }

    public void openMap(View view) {
        startActivity(new Intent(this, MapActivity.class));
    }

    public void call(View v) {

        try {
            Intent intent = new Intent(Intent.ACTION_CALL);
            intent.setData(Uri.parse("tel:1264856875"));
            startActivity(intent);
        } catch (SecurityException ex) {
            Toast.makeText(getApplicationContext(), "Error " + ex.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
    public void openHome(View view) {
        startActivity(new Intent(this, OptionsActivity.class));
    }
}
