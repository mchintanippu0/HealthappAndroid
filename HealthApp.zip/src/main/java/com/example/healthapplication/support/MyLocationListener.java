package com.example.healthapplication.support;

import android.app.Activity;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;

import static android.content.Context.LOCATION_SERVICE;

/**
 * Created by Thilina on 04-Aug-16.
 */

public class MyLocationListener implements LocationListener {

    public static void start(Activity activity) {
        LocationManager locationManager = (LocationManager) activity.getSystemService(LOCATION_SERVICE);
        try {
            locationManager.requestLocationUpdates("gps", 0, 0, new MyLocationListener());
        } catch (SecurityException e) {
        }
    }

    @Override
    public void onLocationChanged(Location location) {
        MyLocation.setLatitude(location.getLatitude());
        MyLocation.setLongitude(location.getLongitude());
    }

    @Override
    public void onStatusChanged(String s, int i, Bundle bundle) {

    }

    @Override
    public void onProviderEnabled(String s) {

    }

    @Override
    public void onProviderDisabled(String s) {

    }

}
