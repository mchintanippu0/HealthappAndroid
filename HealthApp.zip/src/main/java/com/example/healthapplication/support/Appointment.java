package com.example.healthapplication.support;

import android.content.ContentValues;
import android.database.Cursor;
import android.provider.BaseColumns;

public abstract class Appointment implements BaseColumns {
    public static final String TABLE = "appointment";
    public static final String DOCTOR = "doctor";
    public static final String APPOINTMENT_TIME = "appointment_time";
    public static final String USER_ID = "user_id";

    static long appointmentId;

    public static final String CREATE_TABLE_QUERY =
            "CREATE TABLE " + Appointment.TABLE + " (" +
                    Appointment._ID + " INTEGER PRIMARY KEY," +
                    Appointment.DOCTOR + " TEXT," +
                    Appointment.APPOINTMENT_TIME + " DATETIME," +
                    Appointment.USER_ID + " INTEGER ); ";

    public static final String DELETE_TABLE_QUERY =
            "DROP TABLE IF EXISTS " + Appointment.TABLE;

    public static boolean create(String appointmentTime, String doctor) {

        ContentValues values = new ContentValues();
        values.put(APPOINTMENT_TIME, appointmentTime);
        values.put(DOCTOR, doctor);
        values.put(USER_ID, User.userId);

        appointmentId = DB.getDatabase().insert(TABLE, null, values);

        if (appointmentId > 0) {
            return true;
        }
        return false;
    }

    public static Cursor getAppointments(){
        Cursor cursor  =  DB.getDatabase().rawQuery("select * from " + TABLE + " where " + USER_ID + " = " + User.userId, null);

        if(cursor.getCount() > 0){
            return cursor;
        }
        return null;

    }

    public static void delete(int id) {
        DB.getDatabase().execSQL("delete from "+TABLE+" where _id = "+id);
    }
}