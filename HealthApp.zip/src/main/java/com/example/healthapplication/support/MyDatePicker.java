package com.example.healthapplication.support;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.TimePicker;

import java.util.Calendar;

public class MyDatePicker extends DialogFragment implements DatePickerDialog.OnDateSetListener {

    TextView textView;

    public void setTextView(TextView textView) {
        this.textView = textView;
    }

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        // Use the current date as the default date in the picker
        final Calendar c = Calendar.getInstance();
        int year = c.get(Calendar.YEAR);
        int month = c.get(Calendar.MONTH);
        int day = c.get(Calendar.DAY_OF_MONTH);

        // Create a new instance of DatePickerDialog and return it
        return new DatePickerDialog(getActivity(), this, year, month, day);
    }

    public void onDateSet(android.widget.DatePicker view, int year, int month, int day) {
        String dayString = "";
        if(day<10){
            dayString = "0"+day;
        }else{
            dayString = ""+day;
        }
        textView.setText(year + "-" + (++month<10?("0"+month):month )+ "-" + dayString);//2016-08-02
    }

}