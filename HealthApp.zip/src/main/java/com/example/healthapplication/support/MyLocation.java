package com.example.healthapplication.support;

/**
 * Created by Thilina on 04-Aug-16.
 */

public class MyLocation {
    private static double latitude;
    private static double longitude;

    public static double getLatitude() {
        return latitude;
    }

    public static void setLatitude(double latitude) {
        MyLocation.latitude = latitude;
    }

    public static double getLongitude() {
        return longitude;
    }

    public static void setLongitude(double longitude) {
        MyLocation.longitude = longitude;
    }
}
