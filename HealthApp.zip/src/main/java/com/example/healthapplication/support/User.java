package com.example.healthapplication.support;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.provider.BaseColumns;

public abstract class User implements BaseColumns {
    public static final String TABLE = "user";
    public static final String NAME = "name";
    public static final String EMAIL = "email";
    public static final String PASSWORD = "password";
    public static final String AGE = "age";
    public static final String CONTACT = "contact";

    public static long userId;

    public static final String CREATE_TABLE_QUERY =
            "CREATE TABLE " + User.TABLE + " (" +
                    User._ID + " INTEGER PRIMARY KEY," +
                    User.NAME + " TEXT," +
                    User.EMAIL + " TEXT," +
                    User.AGE + " INTEGER," +
                    User.CONTACT + " TEXT," +
                    User.PASSWORD + " TEXT ); ";

    public static final String DELETE_TABLE_QUERY =
            "DROP TABLE IF EXISTS " + User.TABLE;

    public static boolean create(String name, String email, String password) {

        ContentValues values = new ContentValues();
        values.put(NAME, name);
        values.put(EMAIL, email);
        values.put(PASSWORD, password);

        userId = DB.getDatabase().insert(TABLE, null, values);

        if (userId > 0) {
            return true;
        }
        return false;
    }


    public static boolean valid(String email, String password) {
        Cursor cursor  =  DB.getDatabase().rawQuery("select "+_ID+" from " + TABLE + " where " + EMAIL + " = '" + email + "' AND "+PASSWORD+" = '"+password +"'", null);
        if(cursor.getCount() > 0){
            cursor.moveToFirst();
            userId = cursor.getLong(cursor.getColumnIndexOrThrow(_ID));
            return true;
        }
        return false;
        //return DatabaseUtils.queryNumEntries(DB.getDatabase(), "user", "email=? AND password=?", new String[]{email, password}) > 0;
    }

    public static void update(String name, String age, String contact, String email) {
        ContentValues cv = new ContentValues();
        cv.put(NAME,name);
        cv.put(AGE,age);
        cv.put(CONTACT,contact);
        cv.put(EMAIL,email);
        DB.getDatabase().update(TABLE, cv, _ID+" = "+userId, null);
    }
    public static UserPojo getUserPojo(){
        Cursor cursor  =  DB.getDatabase().rawQuery("select * from " + TABLE + " where " + _ID + " = " + userId, null);
        if(cursor.getCount() > 0){
            cursor.moveToFirst();

            UserPojo userPojo = new UserPojo();
            userPojo.setId( cursor.getLong(cursor.getColumnIndexOrThrow(_ID)));
            userPojo.setName( cursor.getString(cursor.getColumnIndexOrThrow(NAME)));
            userPojo.setAge( cursor.getInt(cursor.getColumnIndexOrThrow(AGE)));
            userPojo.setEmail( cursor.getString(cursor.getColumnIndexOrThrow(EMAIL)));
            userPojo.setContact( cursor.getString(cursor.getColumnIndexOrThrow(CONTACT)));
            return userPojo;
        }
        return null;

    }

}