package com.example.healthapplication;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import com.example.healthapplication.support.Appointment;

public class AppointmentListActivity extends AppCompatActivity {
    LinearLayout linLay1,linLay2,linLay3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_appointment_list);
        findViews();
        fillAppointments();
    }

    private void fillAppointments() {
        Cursor cursor = Appointment.getAppointments();
        if (cursor == null) {
            return;
        }

        clearData();
        //linLay1.removeAllViews();
        cursor.moveToFirst();
        while (cursor.isAfterLast() == false) {

            //LinearLayout rowLinLay = new LinearLayout(this);

           // rowLinLay.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT));
            //rowLinLay.setOrientation(LinearLayout.HORIZONTAL);


            //TableRow tr = new TableRow(this);
            //tr.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT, TableRow.LayoutParams.WRAP_CONTENT));


            TextView textView1 = new TextView(this);
            textView1.setText(cursor.getString(1));
            //textView1.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.MATCH_PARENT));
            linLay1.addView(textView1);

            /****************/
            TextView textView2 = new TextView(this);
            textView2.setText(cursor.getString(2));
            //textView2.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.MATCH_PARENT));
            linLay2.addView(textView2);

            TextView textView3 = new TextView(this);
            textView3.setText("Cancel");
            long id = cursor.getLong(cursor.getColumnIndex("_id"));
            textView3.setId((int)id );
            textView3.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int id = view.getId();
                    Appointment.delete(id);
                    Toast.makeText(getApplicationContext(),id +" Deleted", Toast.LENGTH_SHORT).show();
                    openHome(view);

                }
            });
            //textView2.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.MATCH_PARENT));
            linLay3.addView(textView3);

            //linLay.addView(rowLinLay);

            cursor.moveToNext();
        }
        cursor.close();
    }

    private void clearData() {
        int count = linLay1.getChildCount();
        for(int i=count-1; i>0; i--) {
            linLay1.removeViewAt(i);
            linLay2.removeViewAt(i);
            linLay3.removeViewAt(i);
        }
    }

    private void findViews() {
        linLay1 = (LinearLayout) findViewById(R.id.linLay1);
        linLay2 = (LinearLayout) findViewById(R.id.linLay2);
        linLay3 = (LinearLayout) findViewById(R.id.linLay3);
    }

    public void openAppointment(View view) {
        startActivity(new Intent(this, AppointmentActivity.class));
    }
    public void openHome(View view) {
        startActivity(new Intent(this, OptionsActivity.class));
    }
}
