package com.example.healthapplication;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

public class OptionsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_options);
    }

    public void openProfile(View view) {
        startActivity(new Intent(this, ProfileActivity.class));
    }

    public void openMyHealth(View view) {
        startActivity(new Intent(this, MyHealthActivity.class));

    }

    public void openAppointments(View view) {
        startActivity(new Intent(this, AppointmentListActivity.class));
    }

    public void openPayments(View view) {
        startActivity(new Intent(this, PaymentsActivity.class));
    }

    public void openFindUs(View view) {
        startActivity(new Intent(this, FindUsActivity.class));
    }

    public void openDengueTester(View view) {
        startActivity(new Intent(this, DengueTesterActivity.class));
    }

    public void exit(View view) {
        //System.exit(0);
        finish();
    }
}
