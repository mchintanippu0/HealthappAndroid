package com.example.healthapplication;

import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.healthapplication.support.User;
import com.example.healthapplication.support.UserPojo;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class ProfileActivity extends AppCompatActivity {

    ImageView imageView;
    EditText txtName;
    EditText txtAge;
    EditText txtContact;
    EditText txtEmail;
    Bitmap bp;


    ContextWrapper cw;
    File directory;
    File file;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        initVariables();
        loadImageFromStorage();
        findViews();
        fillForm();
    }

    private void initVariables() {
        cw = new ContextWrapper(getApplicationContext());
        directory = cw.getDir("imageDir", Context.MODE_PRIVATE);
        file = new File(directory, "profile.jpg");
    }

    private void fillForm() {
        UserPojo userPojo = User.getUserPojo();
        if (userPojo != null) {
            txtName.setText(userPojo.getName());
            txtAge.setText(userPojo.getAge() == 0 ? "" : Integer.toString(userPojo.getAge()));
            txtContact.setText(userPojo.getContact());
            txtEmail.setText(userPojo.getEmail());
        }
    }

    private void findViews() {
        imageView = (ImageView) findViewById(R.id.imageView);
        txtName = (EditText) findViewById(R.id.txtName);
        txtAge = (EditText) findViewById(R.id.txtAge);
        txtContact = (EditText) findViewById(R.id.txtContact);
        txtEmail = (EditText) findViewById(R.id.txtEmail);
    }

    public void setPicture(View view) {
        Intent intent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(intent, 0);
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (data != null) {
            bp = (Bitmap) data.getExtras().get("data");
            saveToInternalStorage();
            imageView.setImageBitmap(bp);
        }
    }

    private String saveToInternalStorage() {
       // ContextWrapper cw = new ContextWrapper(getApplicationContext());
        //File directory = cw.getDir("imageDir", Context.MODE_PRIVATE);
        //File mypath = new File(directory, "profile.jpg");

        FileOutputStream fos = null;
        try {
            fos = new FileOutputStream(file);
            bp.compress(Bitmap.CompressFormat.PNG, 100, fos);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                fos.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return directory.getAbsolutePath();
    }


    private void loadImageFromStorage() {
        try {
            bp = BitmapFactory.decodeStream(new FileInputStream(file));
            ImageView img = (ImageView) findViewById(R.id.imageView);
            img.setImageBitmap(bp);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void save(View view) {
        String name = txtName.getText().toString();
        String age = txtAge.getText().toString();
        String contact = txtContact.getText().toString();
        String email = txtEmail.getText().toString();
        User.update(name, age, contact, email);
        fillForm();
        Toast.makeText(getApplicationContext(), "Information Updated", Toast.LENGTH_SHORT).show();
        openHome(view);
    }

    public void openHome(View view) {
        startActivity(new Intent(this, OptionsActivity.class));
    }

    public void share(View view) {

        Intent share = new Intent(Intent.ACTION_SEND);
        share.setType("image/jpeg");
        String path = MediaStore.Images.Media.insertImage(getContentResolver(), bp, "Titlee", null);
        Uri imageUri = Uri.parse(path);
        share.putExtra(Intent.EXTRA_STREAM, imageUri);
        startActivity(Intent.createChooser(share, "Selectt"));
    }
}
