package com.example.healthapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.healthapplication.support.Appointment;
import com.example.healthapplication.support.MyDatePicker;
import com.example.healthapplication.support.MyTimePicker;

public class AppointmentActivity extends AppCompatActivity {
    Spinner spinner;
    Button btnDate;
    Button btnTime;
    ArrayAdapter arrayAdapter;
    String array_spinner[] = new String[4];
    MyTimePicker timePicker;
    MyDatePicker datePicker;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_appointment);
        findViews();
        fillDoctors();
        datePicker = new MyDatePicker();
        datePicker.setTextView(btnDate);

        timePicker = new MyTimePicker();
        timePicker.setTextView(btnTime);

        spinner.setAdapter(arrayAdapter);
    }

    private void fillDoctors() {
        array_spinner[0] = "Amanda Rao";
        array_spinner[1] = "John Doe";
        array_spinner[2] = "Michile Cruice";
        array_spinner[3] = "Jim Brown";
        arrayAdapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item, array_spinner);
    }

    private void findViews() {
        spinner = (Spinner) findViewById(R.id.spinner);
        btnDate = (Button) findViewById(R.id.btnDate);
        btnTime = (Button) findViewById(R.id.btnTime);
    }

    public void showDatePicker(View view){
        datePicker.show(getFragmentManager(),"datePicker");
    }

    public void showTimePicker(View view){
        timePicker.show(getFragmentManager(),"timePicker");
    }

    public void placeAppointment(View view){
        String appointmetTime = btnDate.getText().toString()+" "+btnTime.getText().toString()+":00";
        String doctor = spinner.getSelectedItem().toString();


        Toast.makeText(getApplicationContext(), doctor, Toast.LENGTH_SHORT).show();
        Appointment.create(appointmetTime,doctor);
        startActivity(new Intent(this, AppointmentListActivity.class));
    }
    public void openHome(View view) {
        startActivity(new Intent(this, OptionsActivity.class));
    }
}
