package com.example.healthapplication;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;

public class PaymentsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payments);
    }

    public void openHome(View view) {
        startActivity(new Intent(this, OptionsActivity.class));
    }

    public void pay(View view) {
        TextView tv = (TextView) view;
        tv.setText("Paid");
    }
    void sendMail(View view){
        Intent emailIntent = new Intent(android.content.Intent.ACTION_SEND);
        //String aEmailList[] = { "user@fakehost.com","user2@fakehost.com" };
        String aEmailCCList[] = { "admin@healthapp.com"};
        //String aEmailBCCList[] = { "user5@fakehost.com" };

        //emailIntent.putExtra(android.content.Intent.EXTRA_EMAIL, aEmailList);
        emailIntent.putExtra(android.content.Intent.EXTRA_CC, aEmailCCList);
        //emailIntent.putExtra(android.content.Intent.EXTRA_BCC, aEmailBCCList);

        emailIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "Your Bills");

        emailIntent.setType("plain/text");
        String messageBody = " 2016-05-05 \t100.00 \r\n 2016-05-05 \t 75.00 \r\n 2016-05-05 \t150.00";

        emailIntent.putExtra(android.content.Intent.EXTRA_TEXT, messageBody);

        startActivity(emailIntent);
    }
}
