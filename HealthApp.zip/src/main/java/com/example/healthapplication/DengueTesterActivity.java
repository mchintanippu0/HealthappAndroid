package com.example.healthapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class DengueTesterActivity extends AppCompatActivity {

    TextView tvResult;
    EditText txtPlCount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dengue_tester);
        findViews();
    }

    private void findViews() {
        tvResult = (TextView) findViewById(R.id.tvResult);
        txtPlCount = (EditText) findViewById(R.id.txtPlCount);
    }

    public void calculate(View view){
        int plCount = Integer.valueOf(txtPlCount.getText().toString().trim());
        String result = "";
        if(plCount>200000){
            result = "Normal";
        } else if(plCount>150000){
            result = "Be Alert";
        } else if(plCount>100000){
            result = "Suspected";
        } else if(plCount>50000){
            result = "Highly Suspected";
        }else {
            result = "Danger";
        }
        tvResult.setText(result);
    }
}
