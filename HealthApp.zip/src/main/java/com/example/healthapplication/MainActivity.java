package com.example.healthapplication;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.healthapplication.support.DB;
import com.example.healthapplication.support.MyLocationListener;
import com.example.healthapplication.support.PermissionManager;
import com.example.healthapplication.support.User;

public class MainActivity extends AppCompatActivity {

    EditText txtEmail;
    EditText txtPassword;
    EditText txtRegName;
    EditText txtRegEmail;
    EditText txtRegPassword;
    EditText txtRegReEnterPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        PermissionManager.check(this);
        DB.setDatabaseFor(this);
        findViews();
        MyLocationListener.start(this);

    }

    private void findViews() {
        txtEmail = (EditText) findViewById(R.id.txtEmail);
        txtPassword = (EditText) findViewById(R.id.txtPassword);

        txtRegName = (EditText) findViewById(R.id.txtRegName);
        txtRegEmail = (EditText) findViewById(R.id.txtRegEmail);
        txtRegPassword = (EditText) findViewById(R.id.txtRegPassword);
        txtRegReEnterPassword = (EditText) findViewById(R.id.txtRegReEnterPassword);
    }

    public void signUp(View view) {

        String name = txtRegName.getText().toString().trim();
        String email = txtRegEmail.getText().toString().trim();
        String password = txtRegPassword.getText().toString().trim();
        String passwordAgain = txtRegReEnterPassword.getText().toString().trim();

        if (!password.equals(passwordAgain)) {
            Toast.makeText(getApplicationContext(), "Enter Same Passwords", Toast.LENGTH_SHORT).show();
            return;
        }

        if (User.create(name, email, password)) {
            Toast.makeText(getApplicationContext(), "Sign up success, Please Sign in", Toast.LENGTH_SHORT).show();
            clearSignUpForm();
        } else {
            Toast.makeText(getApplicationContext(), "Sign up failed", Toast.LENGTH_SHORT).show();
        }
    }

    private void clearSignUpForm() {
        txtRegName.setText("");
        txtRegEmail.setText("");
        txtRegPassword.setText("");
        txtRegReEnterPassword.setText("");
    }

    public void signIn(View view) {
        String email = txtEmail.getText().toString().trim();
        String password = txtPassword.getText().toString().trim();
        if (User.valid(email, password)) {
            Toast.makeText(getApplicationContext(), "Sign in Success", Toast.LENGTH_SHORT).show();
            clearSignInForm();
            startActivity(new Intent(this, OptionsActivity.class));
        } else {
            Toast.makeText(getApplicationContext(), "Sign in Failed", Toast.LENGTH_SHORT).show();
        }
    }

    private void clearSignInForm() {
        txtEmail.setText("");
        txtPassword.setText("");
    }

}
